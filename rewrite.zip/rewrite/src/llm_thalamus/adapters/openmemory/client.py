from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from llm_thalamus.config.access import get_config

if TYPE_CHECKING:
    from openmemory import Memory  # only for type checking

_MEM: Optional["Memory"] = None
_OM_ENV_LOGGED: bool = False


def _get_cfg() -> Any:
    return get_config()


def _call_if_callable(v: Any) -> Any:
    return v() if callable(v) else v


def _cfg_openmemory_db_path(cfg: Any) -> Path:
    v = getattr(cfg, "openmemory_db_path", None)
    if v is None:
        raise RuntimeError("Config missing required field/method: openmemory_db_path")
    v = _call_if_callable(v)
    return Path(v)


def _cfg_openmemory_db_url(cfg: Any) -> str:
    v = getattr(cfg, "openmemory_db_url", None)
    if v is None:
        raise RuntimeError("Config missing required field/method: openmemory_db_url")
    v = _call_if_callable(v)
    return str(v)


def _cfg_default_user_id(cfg: Any) -> Optional[str]:
    v = getattr(cfg, "default_user_id", None)
    return str(v) if v else None


def _cfg_embeddings_provider(cfg: Any) -> str:
    v = getattr(cfg, "embeddings_provider", None)
    return str(v) if v else ""


def _cfg_embeddings_model(cfg: Any) -> Optional[str]:
    v = getattr(cfg, "embeddings_model", None)
    return str(v) if v else None


def _cfg_ollama_url(cfg: Any) -> str:
    v = getattr(cfg, "ollama_url", None)
    if not v:
        raise RuntimeError("Config missing required field: ollama_url")
    return str(v)


def _cfg_openmemory_tier(cfg: Any) -> str:
    om = getattr(cfg, "openmemory", None)
    tier = getattr(om, "tier", None) if om is not None else None
    return str(tier) if tier else "default"


def _cfg_openmemory_ollama_model(cfg: Any) -> Optional[str]:
    om = getattr(cfg, "openmemory", None)
    model = getattr(om, "ollama_model", None) if om is not None else None
    return str(model) if model else None


def assert_db_present() -> Path:
    cfg = _get_cfg()
    db_path = _cfg_openmemory_db_path(cfg)

    if not db_path.exists():
        raise FileNotFoundError(
            "OpenMemory sqlite DB not found.\n"
            f"Expected path: {db_path}\n"
            "Fix: copy/restore the database to this location (or adjust config/path policy)."
        )
    if not db_path.is_file():
        raise FileNotFoundError(
            "OpenMemory sqlite DB path exists but is not a file.\n"
            f"Expected path: {db_path}"
        )
    return db_path


def get_default_user_id() -> Optional[str]:
    cfg = _get_cfg()
    return _cfg_default_user_id(cfg)


def _configure_openmemory_env() -> None:
    global _OM_ENV_LOGGED

    cfg = _get_cfg()

    provider = _cfg_embeddings_provider(cfg).strip().lower()
    if provider and provider != "ollama":
        raise RuntimeError(
            f"Unsupported embeddings provider '{provider}'. "
            "This migration currently supports provider='ollama' only."
        )

    db_url = _cfg_openmemory_db_url(cfg)
    tier = _cfg_openmemory_tier(cfg)

    embed_model = _cfg_embeddings_model(cfg) or _cfg_openmemory_ollama_model(cfg) or "nomic-embed-text:latest"
    ollama_url = _cfg_ollama_url(cfg)

    os.environ["OM_DB_URL"] = db_url
    os.environ["OM_TIER"] = tier

    os.environ["OM_EMBEDDINGS_PROVIDER"] = "ollama"
    os.environ["OM_OLLAMA_EMBEDDING_MODEL"] = embed_model 
    os.environ["OM_OLLAMA_EMBEDDINGS_MODEL"] = embed_model
    os.environ["OM_OLLAMA_URL"] = ollama_url

    os.environ["OLLAMA_URL"] = ollama_url  # compatibility

    # Compatibility shim for openmemory.core.config.env (if present)
    try:
        from openmemory.core.config import env as om_env  # imported AFTER env set
        if hasattr(om_env, "ollama_base_url"):
            setattr(om_env, "ollama_base_url", ollama_url)
        elif hasattr(om_env, "ollama_url"):
            setattr(om_env, "ollama_url", ollama_url)
    except Exception:
        pass

    if not _OM_ENV_LOGGED:
        _OM_ENV_LOGGED = True
    
    os.environ["LLM_THALAMUS_OM_CONFIGURED"] = "1"


def _construct_memory_explicit(cfg: Any) -> "Memory":
    # Import here to avoid OpenMemory reading defaults before we set env.
    from openmemory import Memory

    db_path = _cfg_openmemory_db_path(cfg)
    db_url = _cfg_openmemory_db_url(cfg)

    for kwargs in (
        {"db_url": db_url},
        {"url": db_url},
        {"database_url": db_url},
        {"db_path": str(db_path)},
        {"path": str(db_path)},
        {"db": str(db_path)},
    ):
        try:
            return Memory(**kwargs)  # type: ignore[arg-type]
        except TypeError:
            continue

    return Memory()


import sys

def get_memory() -> "Memory":
    global _MEM

    if _MEM is not None:
        return _MEM

    # HARD GUARD
    if "openmemory" in sys.modules and not os.environ.get("LLM_THALAMUS_OM_CONFIGURED"):
        raise RuntimeError(
            "OpenMemory was imported before llm_thalamus configured it.\n"
            "Do not import openmemory directly. "
            "Use llm_thalamus.adapters.openmemory.client.get_memory()."
        )

    cfg = _get_cfg()
    _configure_openmemory_env()
    _MEM = _construct_memory_explicit(cfg)
    return _MEM



def run_om_async(awaitable: Any) -> Any:
    try:
        loop = asyncio.get_running_loop()
        if loop.is_running():
            raise RuntimeError(
                "Cannot run OpenMemory async operation inside a running event loop. "
                "Call async APIs directly in async context."
            )
    except RuntimeError:
        pass
    return asyncio.run(awaitable)


async def _search_async(mem: "Memory", query: str, k: int, *, user_id: Optional[str] = None) -> Any:
    kwargs: Dict[str, Any] = {}
    if user_id:
        kwargs["user_id"] = user_id

    for param in ("k", "n", "limit"):
        try:
            return await mem.search(query=query, **{param: int(k)}, **kwargs)
        except TypeError:
            continue

    return await mem.search(query=query, **kwargs)


def search(query: str, k: int = 8, *, user_id: Optional[str] = None) -> List[Dict[str, Any]]:
    mem = get_memory()
    result = run_om_async(_search_async(mem, query=query, k=int(k), user_id=user_id))

    if result is None:
        return []
    if isinstance(result, list):
        return [r for r in result if isinstance(r, dict)]
    if isinstance(result, dict):
        r = result.get("results")
        if isinstance(r, list):
            return [x for x in r if isinstance(x, dict)]
    return []


async def _add_async(mem: "Memory", content: str, **kwargs: Any) -> Any:
    return await mem.add(content, **kwargs)


def add(
    content: str,
    *,
    user_id: Optional[str] = None,
    memory_type: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    tags: Optional[List[str]] = None,
) -> Any:
    mem = get_memory()

    kwargs: Dict[str, Any] = {}
    if user_id:
        kwargs["user_id"] = user_id
    if memory_type:
        kwargs["memory_type"] = memory_type
    if metadata:
        kwargs["metadata"] = metadata
    if tags:
        kwargs["tags"] = tags

    return run_om_async(_add_async(mem, content, **kwargs))


async def _delete_async(mem: "Memory", memory_id: str) -> Any:
    return await mem.delete(memory_id)


def delete(memory_id: str) -> None:
    mem = get_memory()
    run_om_async(_delete_async(mem, memory_id))
